package com.prasanna.billa;

import java.util.concurrent.*;

public class CallableTask {
    public static void main(String[] args) {

        ExecutorService service = Executors.newFixedThreadPool(5);
        Future<Double> doubleFutute =  service.submit(new SumTask(21, 5));
        try {
            System.out.println(doubleFutute.get());
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

    }
}

    class SumTask implements Callable<Double>{

        private int no;
        private int power;
        public SumTask(int _no, int _power){
            this.no = _no;
            this.power = _power;
        }

        @Override
        public Double call() throws Exception {
            return Math.pow(no,power);
        }
    }
