package com.prasanna.billa;

public class Recursion {

    public static void main(String[] args) {
        System.out.println(getFact(5));
        System.out.println(reverseString("How are we doing"));
    }

    public static int getFact(int i){
        int fact = 1;
        if(i>1) {
            fact = fact * i;
            i--;
            getFact(i);
        }
        return fact;
    }

    public static String reverseString(String str)
    {
        if (str.isEmpty())
            return str;
        //Calling Function Recursively
        return reverseString(str.substring(1)) + str.charAt(0);
    }
}
