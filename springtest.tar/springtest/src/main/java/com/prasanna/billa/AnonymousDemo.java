package com.prasanna.billa;


//Java program to demonstrate Anonymous inner class
interface Age
{
    int x = 21;
    void getAge();
}

 interface InterfaceA {
    default void defaultMethod(){
        System.out.println("Interface A default method");
    }
}
 interface InterfaceB {
    default void defaultMethod(){
        System.out.println("Interface B default method");
    }
}
public class AnonymousDemo implements InterfaceA, InterfaceB{

    public static void main(String[] args) {
        InterfaceB b =new AnonymousDemo();
        b.defaultMethod();
    }
    public void defaultMethod(){
        System.out.println("Anonymous demo");
    }
}