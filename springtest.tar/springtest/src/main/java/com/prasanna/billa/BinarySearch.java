package com.prasanna.billa;

public class BinarySearch {

    public static void main(String[] args) {
        int[] arr = {1,2,3,4,5,8,10,11,25,36,44,55,89};
        int ar2[] = {2};
        System.out.println(getIndex(arr, 0,arr.length-1,2));
        System.out.println(mySearch(arr,0,arr.length-1,2));
        //System.out.println(binarySearch(ar2,0,arr.length-1,2));
    }

    public static int getIndex(int arr[],int start, int end, int no){
         if(end>=start) {
            int mid = start + (end - start) / 2;
            if (no == arr[mid]) {
                return mid;
            } else if (arr[mid] > no) {
                return getIndex(arr, start, mid - 1, no);
            } else return getIndex(arr, mid + 1, end, no);
        }
        return -1;
    }

    public static int mySearch(int[] arr, int start, int end, int no){
        int mid =start+(end-start)/2;
        if(arr[mid]==no){
            return mid;
        }
        if(no>arr[mid]){
            return mySearch(arr,mid+1,end,no);
        }
        else return mySearch(arr, start,mid-1,no);
    }

    public static int binarySearch(int arr[], int l, int r, int x) {
        if (r >= l) {
            int mid = l + (r - l) / 2;
            if (arr[mid] == x)
                return mid;

            if (arr[mid] > x)
                return binarySearch(arr, l, mid-1, x);
            return binarySearch(arr, mid+1, r, x);
        }
        else return -1;
    }
}
