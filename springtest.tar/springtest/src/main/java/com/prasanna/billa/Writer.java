package com.prasanna.billa;

import java.io.*;

public class Writer {
    public static void main(String[] args) throws IOException {
        //getWriter();
        try {
            getReader();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private static void getWriter() throws IOException {
        Employee employee = new Employee();
        employee.setName("Ashintha");
        employee.setAge((byte) 30);
        employee.setAddress("Galle");
        FileOutputStream fout = new FileOutputStream("/home/halcyon/prasanna/employee.txt");
        ObjectOutputStream oos = new ObjectOutputStream(fout);
        oos.writeObject(employee);
        oos.close();
        System.out.println("Process complete");
    }


    public static void getReader() throws ClassNotFoundException, IOException {
        Employee employee ;
        FileInputStream fin = new FileInputStream("/home/halcyon/prasanna/employee.txt");
        ObjectInputStream ois = new ObjectInputStream(fin);
        employee = (Employee) ois.readObject();
        ois.close();
        System.out.println(employee.whoIsThis());
    }
}
