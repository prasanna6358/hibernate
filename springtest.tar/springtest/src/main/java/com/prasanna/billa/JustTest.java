package com.prasanna.billa;

public abstract class JustTest {

   abstract void eat();
    abstract void sleep();
}
