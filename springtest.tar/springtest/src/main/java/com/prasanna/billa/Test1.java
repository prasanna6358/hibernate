package com.prasanna.billa;

 class Test2
{
    public Test2(){
        System.out.println("print");
    }
    public void getName(){
        System.out.println("prasanna");
    }
}


public class Test1
{
    public static void main(String[] args)
    {
        Test2 t= new Test2();
        t.getName();

    }

}