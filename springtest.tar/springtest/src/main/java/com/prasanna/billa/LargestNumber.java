package com.prasanna.billa;

public class LargestNumber {

    public static void main(String[] args) {

    }

    public static void getNumber(int no){
        int firstDigit = Integer.valueOf(String.valueOf(no).toCharArray()[0]);

    }
}
