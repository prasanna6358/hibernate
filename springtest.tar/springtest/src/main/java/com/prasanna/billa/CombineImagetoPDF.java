package com.prasanna.billa;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class CombineImagetoPDF {
    public static final String[] IMAGES = {
            "/home/halcyon/Downloads/img001.jpg",
            "/home/halcyon/Downloads/img002.jpg",
            "/home/halcyon/Downloads/img003.jpg"
    };
    public static final String DEST = "/home/halcyon/Downloads/img004.pdf";

    public static void main(String[] args) throws IOException, DocumentException {
        File file = new File(DEST);
        file.getParentFile().mkdirs();
        new CombineImagetoPDF().createPdf(DEST);
    }
    public void createPdf(String dest) throws IOException, DocumentException {
        Image img = Image.getInstance(IMAGES[0]);
        Document document = new Document(img);
        PdfWriter.getInstance(document, new FileOutputStream(dest));
        document.open();
        for (String image : IMAGES) {
            img = Image.getInstance(image);
            document.setPageSize(img);
            document.newPage();
            img.setAbsolutePosition(0, 0);
            document.add(img);
            document.newPage();
        }
        document.close();
    }
}
