package com.prasanna.billa;



public class MinMaxNumber {

    public static void main(String[] args) {
      getNumber(795);
        System.out.println(System.getenv("VAR2"));
        String userWindows = System.getenv("JAVA_HOME");
        System.out.println("Username using environment variable in windows : "  + userWindows);

    }

    private static int largestno=0;
    private static int actualNo=0;
    public static void getNumber(int no){
        actualNo=no;
        while (!checkNo(no)){
            no=no-1;
        }
        System.out.println(largestno);
    }

    public static boolean checkNo(int no){
        largestno = no-1;
        char[] char1 = String.valueOf(actualNo).toCharArray();
        char[] char2 = String.valueOf(largestno).toCharArray();

        for(int i=0;i<char1.length;i++){
            for(int j=0;j<char2.length;j++){
                if(char1[i]==char2[j]){
                    return false;
                }
            }
        }
        return true;
    }


    public static void getMinMaxNumbers(int[] arr) {
        int min = arr[0];
        int max =arr[0];
        for (int i = 0; i < arr.length; i++) {
            if (min > arr[i]) {
                min = arr[i];
            }
            if (max < arr[i]) {
                max = arr[i];
            }
        }
        System.out.println("min is " + min + " max is " + max);
    }

    public static boolean consecutiveORnot(int[] arr) {

        boolean value = false;
        for (int i = 1; i < arr.length; i++) {
            if ((arr[i] - arr[i -1]) ==1 || (arr[i] - arr[i -1]) ==0) {
                value = true;
            }
            else return false;
        }
        return value;
    }

    public static int[] sortArray(int arr[]){
        int temp;
        for (int i=0;i<arr.length;i++){
            for(int j=i;j<arr.length;j++){
                if(arr[i]>arr[j]){
                    temp=arr[i];
                    arr[i]=arr[j];
                    arr[j]=temp;
                }
            }
        }
        return arr;
    }


    public static void testPattern(String str, String pattern){

    }

    public static void recursivePrint(int num) {
        System.out.println("Number: " + num);
        if(num == 0)
            return;
        else
            recursivePrint(++num);
    }

    public static void getBitSets(int no){
        int bitsets = 0;
        for(int i=1;i<=no;i++) {
            bitsets=bitsets+bitSetCount(i);
        }
        System.out.println("Total no of bit sets "+bitsets);
    }

    public static int bitSetCount(int x){
        if(x<=0)
            return 0;
        return (x % 2 == 0 ? 0 : 1) +
                bitSetCount(x / 2);
    }


    static int countSetBits( int n){
        int bitCount = 0;
        for (int i = 1; i <= n; i++)
            bitCount += countSetBitsUtil(i);
        return bitCount;
    }

    static int countSetBitsUtil( int x) {
        if (x <= 0)
            return 0;
        return (x % 2 == 0 ? 0 : 1) +
                countSetBitsUtil(x / 2);
    }

    public static void printNoEnd(int no){
        if(no!=0){
            System.out.println(no);
            no++;
        }
        printNoEnd(no);
    }
}