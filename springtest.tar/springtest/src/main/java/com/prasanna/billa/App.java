package com.prasanna.billa;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class App {

    public static void main(String[] args) {

    /*    Double d1 = new Double("0.0");
        Double d2 = new Double("1.0");
        System.out.println("output : "+d1/d2); // gives output as "infinity" without error
        System.out.println("output : "+d2/d1);*/

        Map<Integer, String> mk = new HashMap();
        mk.put(5,"prasanna");
        mk.put(2,"gajanan");
        mk.put(4,"sunil");
        mk.entrySet().forEach(entry -> System.out.println(entry.getKey()+" "+entry.getValue()));
        Map<Integer, String> tm = new TreeMap(mk);
        tm.entrySet().forEach(entry -> System.out.println(entry.getKey()+" "+entry.getValue()));


        WriteDataToFile("Hello I'm Prasanna");

        //testSpringBeans();
    }

    private static void testSpringBeans() {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        Student student  =(Student)context.getBean("studentbean");
        Address address  =(Address) context.getBean("addressBean");
        System.out.println(address.getLocation());
        student.displayInfo();
        System.out.println(student.toString());
        List<Courses> courses = student.getCourses();
        courses.forEach(courses1 -> System.out.println(courses1.getCourseId()+" "+courses1.getCourseName()));
    }

    private static void WriteDataToFile(String data) {
           File file =  new File("/home/halcyon/input.txt");
        FileOutputStream fos = null; try {
            fos = new FileOutputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        };
        try {
            fos.write(data.getBytes(), 0, data.length());
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}


