package com.prasanna.billa;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;



public class ThreadTest  {

    public void print(String m) {
        System.out.println(m);
    }

    JustTest justTest = new JustTest() {
        @Override
        void eat() {
            System.out.println("eat");
        }

        @Override
        void sleep() {
            System.out.println("sleep");
        }
    };


    public class One implements Callable<Integer> {

        public Integer call() throws Exception {
            print("One...");
            Thread.sleep(6000);
            print("One!!");
            return 100;
        }
    }

    public class Two implements Callable<String> {

        public String call() throws Exception {
            print("Two...");
            Thread.sleep(1000);
            print("Two!!");
            return "Done";
        }
    }

    public class Three implements Callable<Boolean> {

        public Boolean call() throws Exception {
            print("Three...");
            Thread.sleep(2000);
            print("Three!!");
            return true;
        }
    }

    /**
     * @See java.util.concurrent.Future.get() doc
     *      <p>
     *      Waits if necessary for the computation to complete, and then
     *      retrieves its result.
     */

    public static void main(String[] args) {
        try {
            new ThreadTest().poolRun();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }
    public  void poolRun() throws InterruptedException, ExecutionException {
        int n = 3;
        // Build a fixed number of thread pool
        ExecutorService pool = Executors.newFixedThreadPool(n);
        // Wait until One finishes it's task.
        System.out.println(pool.submit(new One()));//.get());
        // Wait until Two finishes it's task.
        System.out.println(pool.submit(new Two()));//.get());
        // Wait until Three finishes it's task.
        System.out.println(pool.submit(new Three()));//.get());
        pool.shutdown();
    }
}