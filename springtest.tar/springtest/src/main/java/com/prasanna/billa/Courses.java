package com.prasanna.billa;

public class Courses {
    private String courseId;
    private String courseName;

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
    public String getCourseId() {
        return courseId;
    }
    public String getCourseName() {
        return courseName;
    }
}
