package com.app.billa;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class HomeController {

    CountryService countryService = new CountryService();

    @RequestMapping("/")
    public ModelAndView shoePage(ModelAndView modelObject){
        List<Country> countryList =countryService.getAllConutries();
        modelObject.addObject("countries",countryList);
        modelObject.setViewName("home");
        return modelObject;
    }
}
