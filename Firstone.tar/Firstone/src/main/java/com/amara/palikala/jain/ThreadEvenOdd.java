package com.amara.palikala.jain;

public class ThreadEvenOdd implements Runnable{

    @Override
    public void run() {

    }
}
